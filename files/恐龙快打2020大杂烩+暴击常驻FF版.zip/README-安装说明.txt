【恐龙快打·2020大杂烩多模式加强版 + 暴击常驻FF + sunjunior署名】(v16稳定版)

基座：zengfr 2020 大杂烩多模式加强版（世界版壳 dino），特性：
  - 主角/敌兵 8 倍血量、多层血条
  - 投币后上下键选 MODE（0A~59）：十位=纯Boss/混兵规则、个位=同屏敌兵数
  - 部分模式枪械无限弹药

暴击补丁（v13 架构，3 挂点 + 守卫 stub，全在 21a）：
  把玩家对象暴击字节全程钉 $FF —— 拳/脚/摔/武器/枪械/手雷每击满暴击，
  HUD 常驻 FF；共享例程按 32 位玩家基址($FFFFB274/3F4/574)守卫，Boss、
  车辆、小兵逐条原版回放，敌兵伤害/二关Boss/三关开车霍戈/过关流程均正常。

署名替换（v16，等长文本替换，保留 / 行终止符与 @ 尾标记）：
  标题画面 "Rom Hacked By Zengfr 2020.05" -> "Rom Hacked By sunjunior"
  URL 行  -> "Https:\sunjunior.github.io"；滚动职员表 -> "2020,sunjunior"

安装：解压得到 dino.zip，放入 MAME roms 根目录（文件名必须 dino.zip，
  对应机台 dino）。与美版 dinou.zip 可共存。

MAME：0.149~0.289 实测可玩；启动报 checksum 警告选 ignore 即可。
SHA1(包内dino.zip): 8056f85ca8d7925db1b2cbcacb9074fc8016171d
