【恐龙快打 随机出兵强化 + 持道具暴击版本】(v11)
功能：正常单波出兵 / 敌兵运行时随机强化(Walther级) / 持道具攻击必暴击(暴击槽恒定$90满档) / 100%掉落M16 48发
安装：解压得到 dinou.zip，整个放进 MAME 的 roms 目录启动。
MAME 0.106+ 实测；checksum 提示选 ignore。世界版：解出内层 dinou.zip 的 cdu_* 改名 cde_* 打包进 dino.zip。
