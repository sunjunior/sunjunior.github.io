【恐龙快打 双倍出兵变态 + 持道具暴击版本】(v11)
功能：双倍密集出兵 / 敌兵运行时随机强化(Walther级) / 持道具攻击必暴击(暴击槽恒定$90满档) / 100%掉落M16 48发
安装：解压得到 dinou.zip，整个放进 MAME 的 roms 目录启动（文件名保持 dinou.zip）。
MAME 0.106+ 实测；checksum 提示选 ignore。世界版：把包内 cdu_* 改名 cde_* 后 zip 进 dino.zip。
