【使用方法】二选一：
1) 把 dinou.zip 整个放进 MAME 的 roms 目录 → 选 dino/dinou 机台启动即可（文件名就是 dinou.zip，无需改名、无需解包）。
2) 若你的 MAME 已有正版 dinou.zip，可覆盖芯片文件：
   zip -q roms/dinou.zip cdu_21a.6f cdu_22a.7f cdu_23a.8f

版本：双倍出兵变态 + 持道具暴击 + 100%掉落M16 + 敌兵运行时随机强化
MAME：任何加载 dinou 的 0.106+ 版本均实测可玩；校验和提示不一致选 ignore。
